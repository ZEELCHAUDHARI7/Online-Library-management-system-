<div class="footer">
	<div class="container">
		<b class="copyright">&copy; <?php echo e(date('Y')); ?> - Library Management System </b> All rights reserved.
	</div>
</div>
<?php /**PATH C:\xampp\htdocs\Laravel-Library-Management-system-main\resources\views/layout/template_footer.blade.php ENDPATH**/ ?>