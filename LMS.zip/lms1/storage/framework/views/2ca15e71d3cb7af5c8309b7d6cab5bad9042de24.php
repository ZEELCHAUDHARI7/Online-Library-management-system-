<div class="alert alert-<%= obj.type %> alert-dismissable center-block">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>    
    <%= obj.message %>
</div><?php /**PATH C:\xampp\htdocs\Laravel-Library-Management-system-main\resources\views/underscore/alert_box.blade.php ENDPATH**/ ?>