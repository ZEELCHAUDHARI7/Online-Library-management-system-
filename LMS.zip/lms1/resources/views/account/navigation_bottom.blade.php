<div class="footer">
	<div class="container">
		<b class="copyright">&copy; {{ date('Y') }} - Online Library Management System </b> All rights reserved.
	</div>
</div>
